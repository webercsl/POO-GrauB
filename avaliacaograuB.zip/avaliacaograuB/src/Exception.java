public class Exception extends NumException {
}
