public interface Verifica {

    void validar();
}
