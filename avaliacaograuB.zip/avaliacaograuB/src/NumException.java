public class NumException extends Throwable {

    public void impMsg() {
        System.out.println("ERRO: Não pode haver Número Negativo para conta!");
    }
}
